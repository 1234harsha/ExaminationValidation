﻿using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Repository
{
    public interface IExamination
    {
        void Add(Examinations examinations);
        void Update(Examinations examinations);
        void Delete(string eId);
        List<Examinations> GetAll();

        Examinations GetExamById(string eId);

    }
}
