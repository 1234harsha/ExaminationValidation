﻿using Microsoft.EntityFrameworkCore;
using NexusProjectIntegration.Entity;
using System.Runtime.InteropServices;

namespace SchoolManagementApi.Entity
{
    public class MyContext:DbContext
    {
        public IConfiguration Configuration;

        public MyContext(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {

            builder.Entity<Students>()
                .HasIndex(u => u.RollNO)
                .IsUnique(true);
            builder.Entity<Users>()
                .HasIndex(u => u.UserName)
                .IsUnique(true);
            builder.Entity<Subject>()
                .HasIndex(u => u.SubName)
                .IsUnique(true);

        }

        public DbSet<Teachers> Teachers { get; set; }
        public DbSet<Students> Students { get; set; }
        public DbSet<Classes> Classes { get; set; }
        public DbSet<StudentAttendance> StudentAttendance { get; set; }
        public DbSet<TeacherAttendance> TeacherAttendance { get; set; }
        public DbSet<Examinations> Examinations { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Marks> Marks { get; set; }
        public DbSet<StudentRegister> StudentRegisters { get; set; }
        public DbSet<TeacherRegister> TeacherRegisters { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(Configuration.GetConnectionString("MyConnection"));
        }

    }
}
