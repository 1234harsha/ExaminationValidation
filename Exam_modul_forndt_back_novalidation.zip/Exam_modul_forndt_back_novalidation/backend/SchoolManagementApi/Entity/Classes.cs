﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolManagementApi.Entity
{
    public class Classes
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string ClassId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Section { get; set; }
        [Required]
        public string TeachId {  get; set; }

        [ForeignKey("TeachId")]
        public Teachers ?Teacher { get; set; }

    }
}
