﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using SchoolManagementApi.DTO;
using SchoolManagementApi.Entity;
using SchoolManagementApi.Repository;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExaminationController : ControllerBase
    {
        private readonly ExaminationRepository examinationRepository;
        private readonly IMapper mapper;
        private readonly MyContext context;
        public ExaminationController(ExaminationRepository examinationRepository,IMapper mapper,MyContext myContext)
        {
            this.examinationRepository = examinationRepository; 
            this.mapper = mapper;
            this.context = myContext;
        }

        [HttpGet,Route("GetExamination")]
        public IActionResult GetAllExams()
        {
            try
            {
                List<Examinations> exam = examinationRepository.GetAll().ToList();
                List<Examinationdto> getall = mapper.Map<List<Examinationdto>>(exam);

                int i = 0;
                foreach(Examinationdto e in getall)
                {
                         e.ClsName = (from c in context.Classes
                             where c.ClassId == exam[i].ClassId
                             select c.Name).Single();
                         e.subject = (from c in context.Subjects
                                 where c.SubId == exam[i].SubjectId
                                 select c.SubName).Single();
                    i++;
                }



                return Ok(getall);
                
            }

            catch (Exception)
            {
                return StatusCode(500, "An error occurred while processing your request."); // Return 500 status code with error message
            }

        }
        [HttpGet,Route("GetExamById/{id}")]

        public IActionResult GetByIdExam(string id) 
        {
            try
            {
                Examinations exam = examinationRepository.GetExamById(id);
                Examinationdto getbyid = mapper.Map<Examinationdto>(exam);

                getbyid.ClsName = (context.Classes.SingleOrDefault(c => c.ClassId == exam.ClassId)).Name;
                getbyid.subject = (context.Subjects.SingleOrDefault(c => c.SubId == exam.SubjectId)).SubName;


                return Ok(getbyid);
            }
            catch (Exception ex)
            {

                return StatusCode(500,ex.Message );
            }


        }
        [HttpPut,Route("EditExam")]
        public IActionResult EditExam([FromBody] ExaminationAddDto examinations)
        {
            try
            {
                Examinations EditExam = mapper.Map<Examinations>(examinations);

                if (ModelState.IsValid)
                {
                    examinationRepository.Update(EditExam);

                    return Ok(EditExam);
                }

                return new JsonResult("Something went wrong") { StatusCode = 500 };
            }
            catch (Exception ex)
            {

                return StatusCode(500, ex.Message);


            }
        }

        [HttpPost,Route("AddExam")]
        public IActionResult AddExam([FromBody] ExaminationAddDto examinations)
        {
            try
            {
                Examinations AddExam = mapper.Map<Examinations>(examinations);

                if (ModelState.IsValid)
                {
                    examinationRepository.Add(AddExam);

                          
                }
                return Ok(AddExam);
                //return new JsonResult("Something went wrong") { StatusCode = 500 };
            }
            catch (Exception mx)
            {
                return StatusCode(500, mx.Message);

            }
        }
        [HttpDelete, Route("Delete Exam/{id}")]

        public IActionResult DeleteExam(string id) 
        {

            try
            {
                examinationRepository.Delete(id);
                return Ok("Exam is deleted successfully");
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }


    }
}
