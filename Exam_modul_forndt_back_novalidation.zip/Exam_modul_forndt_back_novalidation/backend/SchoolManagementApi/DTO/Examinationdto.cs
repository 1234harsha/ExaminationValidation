﻿using SchoolManagementApi.Entity;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SchoolManagementApi.DTO
{
    public class Examinationdto
    {
        public string ExamId { get; set; }
        public string ExamName { get; set; }
      
        public DateTime ExamDate { get; set; }


      

        public string ClassId { get; set; }

        public string SubjectId { get; set; }



        public string ClsName { get; set; }

        public string subject { get; set; }

    }
}
