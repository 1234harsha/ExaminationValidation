import logo from './logo.svg';
import './App.css';
import CRUD from './CRUD';

function App() {
  return (
    <div className="App">
      <div className='container'>
        <h2 className='text-center' style={{textDecoration:"underline"}} >Examination Board</h2>
        <div className='row pt-5'>
        <CRUD/>
        </div>
      </div>
    </div>
  );
}

export default App;
